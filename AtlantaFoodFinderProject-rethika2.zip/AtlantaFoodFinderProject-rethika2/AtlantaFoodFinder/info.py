from django.conf.global_settings import EMAIL_HOST_PASSWORD

EMAIL_USE_TLS = True
EMAIL_HOST = "smtp.gmail.com"
EMAIL_HOST_USER = 'atlfoodfinder2340@gmail.com'
EMAIL_HOST_PASSWORD = 'team292340'
EMAIL_PORT = 587